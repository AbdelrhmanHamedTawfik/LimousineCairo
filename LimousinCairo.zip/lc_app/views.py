from django.shortcuts import render
from django.http import HttpResponse
from django.http import JsonResponse
from .models import *


def index(request):
    Services = Service.objects.all()
    Cars = Car.objects.all()
    Drivers = Driver.objects.all()
    Testimonials = Testimonial.objects.all()
    ContactInfos = ContactInfo.objects.get(pk=1)
    Map_obj = Map.objects.get(pk=1)
    Socials = Social.objects.all()
    SliderImages = SliderImage.objects.all()
    Section_1 = Section.objects.get(pk=1)
    Section_2 = Section.objects.get(pk=2)
    Section_3 = Section.objects.get(pk=3)
    Section_4 = Section.objects.get(pk=4)
    context = {
        'Services': Services,
        'Cars': Cars,
        'Drivers': Drivers,
        'Testimonials': Testimonials,
        'Map': Map_obj,
        'ContactInfo': ContactInfos,
        'Socials': Socials,
        'Section_1': Section_1,
        'Section_2': Section_2,
        'Section_3': Section_3,
        'Section_4': Section_4,
        'SliderImages': SliderImages,
        'Range': range(1,6),
    }
    
    return render(request, 'index.html', context)