from django.db import models
from django.core.validators import RegexValidator
from django.core.files.base import ContentFile
from .templatetags import extras

class Service(models.Model):
    title = models.CharField(max_length=200)
    title_ar = models.CharField(max_length=200)
    image = models.ImageField(upload_to=extras.PathRename('static/assets/services/'), storage=extras.OverwriteStorage())
    description = models.CharField(max_length=1000)
    description_ar = models.CharField(max_length=1000)
    summary = models.CharField(max_length=50, default='Random Text')
    summary_ar = models.CharField(max_length=50, default='Random Text')
    page = models.FileField(upload_to='static/pages/services/', blank=True, null=True, storage=extras.OverwriteStorage())

    def save(self, *args, **kwargs):
        self.page.save(self.title + '.html', ContentFile(extras.createHTML(self).encode('utf-8')), save=False)
        return super().save(*args, **kwargs)
    
    def __str__(self):
        return self.title

class Car(models.Model):
    image = models.ImageField(upload_to=extras.PathRename('static/assets/cars/'), storage=extras.OverwriteStorage())
    name = models.CharField(max_length=200)
    name_ar = models.CharField(max_length=200)
    model = models.CharField(max_length=200)
    model_ar = models.CharField(max_length=200)

    def __str__(self):
        return self.name


class Driver(models.Model):
    name = models.CharField(max_length=200)
    name_ar = models.CharField(max_length=200)
    profile_picture = models.ImageField(upload_to=extras.PathRename('static/assets/drivers/'), storage=extras.OverwriteStorage())
    rating = models.DecimalField(max_digits=2, decimal_places=1)
    year_of_exp = models.IntegerField()
    rides_no = models.IntegerField()

    def __str__(self):
        return self.name

class Testimonial(models.Model):
    name = models.CharField(max_length=200)
    name_ar = models.CharField(max_length=200)
    quote = models.CharField(max_length=500)
    quote_ar = models.CharField(max_length=200)

    def __str__(self):
        return self.name
    
class Section(models.Model):
    title = models.CharField(max_length=200)
    title_ar = models.CharField(max_length=200)
    description = models.CharField(max_length=1000)
    description_ar = models.CharField(max_length=1000)

    def __str__(self):
        return self.title

class Social(models.Model):
    link = models.CharField(max_length=1000)
    title = models.CharField(max_length=50)
    title_ar = models.CharField(max_length=50)
    SOCIAL_CHOICES = (
        ('facebook','FaceBook'),
        ('whatsapp', 'Whats App'),
        ('phone','Mobile'),
        ('instagram','Instagram')
    )
    platform = models.CharField(max_length=20, choices=SOCIAL_CHOICES, default='facebook')

    def __str__(self):
        return self.title
    
class Map(models.Model):
    location_name = models.CharField(max_length=100, default='Home')
    link = models.CharField(max_length=1000)

    def __str__(self):
        return self.location_name
    
class ContactInfo(models.Model):
    address = models.CharField(max_length=1000)
    address_ar = models.CharField(max_length=1000)
    phone_1 = models.CharField(max_length=11, validators=[RegexValidator(r'^\d{1,10}$')])
    phone_2 = models.CharField(max_length=11, validators=[RegexValidator(r'^\d{1,10}$')])
    email = models.EmailField(max_length=254)

    def __str__(self):
        return self.address
    
class SliderImage(models.Model):
    image = models.ImageField(upload_to=extras.PathRename('static/assets/slider/'), storage=extras.OverwriteStorage())
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name