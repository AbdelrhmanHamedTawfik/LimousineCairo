from django.apps import AppConfig


class LimoCairoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'lc_app'
