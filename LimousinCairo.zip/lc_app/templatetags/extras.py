import os
from django import template
from ..models import *
from django.core.files.storage import FileSystemStorage
from django.utils.deconstruct import deconstructible
from uuid import uuid4

register = template.Library()

def get_decimal(value):
    i, f = divmod(value, 1)
    round_value = int(i + ((f >= 0.5) if (value > 0) else (f > 0.5)))
    return round_value - value

register.filter('get_decimal', get_decimal)


class OverwriteStorage(FileSystemStorage):
    def get_available_name(self, name, max_length=None):
        if self.exists(name):
            os.remove(os.path.join(name))
        return name

@deconstructible
class PathRename(object):

    def __init__(self, sub_path):
        self.path = sub_path

    def __call__(self, instance, filename):
        ext = filename.split('.')[-1]
        # get filename
        if instance.pk:
            filename = '{}.{}'.format(instance.pk, ext)
        else:
            # set filename as random string
            filename = '{}.{}'.format(uuid4().hex, ext)
        # return the whole path to the file
        return os.path.join(self.path, filename)

def createHTML(instance):
    return (
        '''
        <div class="content-en">
            <div class="modal-header">
                <div class="modal-image-box">
                    <img class="modal-image" src="''' + instance.image.url + '''"  alt="...">
                    <div class="modal-image-text">'''+  instance.title + '''</div>
                </div>
            </div>
            <div class="modal-body">
                <div class="modal-text">'''+  instance.description + '''</div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
        <div class="content-ar">
            <div class="modal-header">
                <div class="modal-image-box">
                    <img class="modal-image" src="''' + instance.image.url + '''"  alt="...">
                    <div class="modal-image-text">'''+  instance.title_ar + '''</div>
                </div>
            </div>
            <div class="modal-body">
                <div class="modal-text">'''+  instance.description_ar + '''</div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">اغلاق</button>
            </div>
        </div>'''
    )